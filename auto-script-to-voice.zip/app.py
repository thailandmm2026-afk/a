import gradio as gr
from google import genai
import json
import os
from datetime import datetime, timedelta

# 📂 အချက်အလက်များကို အသေမှတ်ထားမည့် JSON Database ဖိုင်အမည်
DB_FILE = "recap_users_db.json"

# 🔑 စတင်အသုံးပြုချိန်တွင် ပါဝင်မည့် အခြေခံ အကောင့်များ
DEFAULT_DB = {
    "admin": {
        "password": "241212",  # 👑 Admin အတွက် Password
        "role": "admin"
    },
    "user1": {
        "password": "456456",    # 🆓 Free User အတွက် Password
        "role": "free",
        "last_used_date": "",
        "usage_count": 0
    }
}

# 🔄 Database ဖတ်သည့် စနစ်
def load_db():
    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_DB, f, indent=4, ensure_ascii=False)
        return DEFAULT_DB
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return DEFAULT_DB

# 💾 Database သိမ်းဆည်းသည့် စနစ်
def save_db(db_data):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db_data, f, indent=4, ensure_ascii=False)

# 🔐 Login စစ်ဆေးပေးမည့် Function
def check_login(username, password):
    username = username.strip()
    password = password.strip()
    
    db = load_db()
    
    if username in db and db[username]["password"] == password:
        user_info = db[username]
        role = user_info["role"]
        
        if role == "member":
            expiry = datetime.strptime(user_info["expiry_date"], "%Y-%m-%d")
            if datetime.now() > expiry:
                return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), f"🚫 အသုံးပြုသူ '{username}' သည် သက်တမ်းကုန်ဆုံးသွားပါပြီ။"
            role_text = f"⭐ PAID MEMBER (သက်တမ်းကုန်ရက် - {user_info['expiry_date']})"
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), f"✅ အောင်မြင်စွာ ဝင်ရောက်ပြီးပါပြီ။ [{role_text}]"
            
        elif role == "admin":
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=True), "👑 မင်္ဂလာပါ ADMIN ကြီးဗျာ။ စနစ်တစ်ခုလုံးကို စီမံခန့်ခွဲနိုင်ပါပြီ။"
            
        elif role == "free":
            return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False), "🆓 FREE USER အဖြစ် အောင်မြင်စွာ ဝင်ရောက်ပြီးပါပြီ။ (တစ်နေ့ ၁ ကြိမ် ကန့်သတ်ချက်ရှိ)"
            
    return gr.update(visible=True), gr.update(visible=False), gr.update(visible=False), "❌ Username သို့မဟုတ် Password မှားယွင်းနေပါသည်။"

# =====================================================================
# 🚀 MAIN RECAP PROCESSOR (With Security & Usage Limit)
# =====================================================================
def process_movie_recap(logged_in_user, movie_name, episode_part, movie_context, api_key, duration_choice, progress=gr.Progress(track_tqdm=True)):
    if not logged_in_user:
        return "🔒 ကျေးဇူးပြု၍ စနစ်အတွင်းသို့ အရင် Login ဝင်ပေးပါ။"
    if not api_key or api_key.strip() == "":
        return "⚠️ ကျေးဇူးပြု၍ သင်၏ Gemini API Key ကို အရင်ထည့်ပေးပါဗျာ।"
    if not movie_name or movie_name.strip() == "":
        return "⚠️ ကျေးဇူးပြု၍ ရုပ်ရှင် သို့မဟုတ် စီးရီးနာမည်ကို ထည့်သွင်းပေးပါဗျာ।"

    db = load_db()
    if logged_in_user not in db:
        return "❌ အသုံးပြုသူ မရှိတော့ပါ။"
        
    user_info = db[logged_in_user]
    today_str = datetime.now().strftime("%Y-%m-%d")
    
    # 🛡️ Limit စစ်ဆေးခြင်းစနစ် (Free & Member)
    if user_info["role"] != "admin":
        if user_info.get("last_used_date") == today_str and user_info.get("usage_count", 0) >= 1:
            return "🚫 သင်သည် ယနေ့အတွက် ပြုလုပ်ခွင့် (၁) ကြိမ် ပြည့်သွားပါပြီ။ နောက်နေ့မှ ပြန်လည် စမ်းသပ်ပါရန်။"

    if duration_choice == "Short (TikTok/Reels - 1 Min)":
        word_count = "စာလုံးရေ ၃၀၀ ကျော် မှ ၅၀၀ အတွင်း"
        length_desc = "၁ မိနစ်စာ Short ဗီဒီယို"
    elif duration_choice == "Medium (YouTube - 3 to 5 Mins)":
        word_count = "စာလုံးရေ ၁၅駒ာ် မှ ၂၀၀၀ အတွင်း"
        length_desc = "၃ မိနစ်မှ ၅ မိနစ်စာ YouTube ဗီဒီယို"
    else:
        word_count = "စာလုံးရေ ၃၀၀0 ကျော် မှ ၄၀၀၀ အတွင်း"
        length_desc = "၁၅ မိနစ်စာ YouTube Long-form ဗီဒီယို"

    additional_context = ""
    if movie_context and movie_context.strip() != "":
        additional_context = f"\n[ဤရုပ်ရှင်၏ စစ်မှန်သော ဇာတ်လမ်း Context အချက်အလက်များ -\n{movie_context.strip()}]\n"

    try:
        client = genai.Client(api_key=api_key.strip())
        movie_info = f"ရုပ်ရှင်/စီးရီး နာမည်ဖြစ်သည့် '{movie_name.strip()}' ကို အခြေခံပါ။ "
        episode_info = f"အထူးသဖြင့် '{episode_part.strip()}' ၏ ဇာတ်လမ်းတစ်ခုလုံးကို " if episode_part and episode_part.strip() else "ဇာတ်လမ်းတစ်ခုလုံးကို "

        progress(0.50, desc="⚡ Gemini AI ကနေ ဇာတ်လမ်းကို အစအဆုံး ပေါင်းစပ်ပြီး ရေးသားနေပါသည်...")
        
        script_prompt = (
            f"မင်းက ရုပ်ရှင်နှင့် စီးရီးများကို Recap လုပ်တဲ့ Professional Content Creator တစ်ယောက် ဖြစ်တယ်။ "
            f"{movie_info} {episode_info} "
            f"တစ်ဝက်တစ်ပျက်နှင့် ဖြတ်မချထားဘဲ၊ အစ-အလယ်-အဆုံး ဇာတ်သိမ်းပိုင်းအထိ (ထို Episode သို့မဟုတ် ဇာတ်ကား၏ ဇာတ်သိမ်းခန်းအထိ) ပြီးပြည့်စုံစွာ ပါဝင်သော {length_desc} အတွက် မြန်မာလို Video Recap Script တစ်ခုကို ရေးပေးပါ။"
            f"{additional_context}\n\n"
            f"သတ်မှတ်ချက်များ (မဖြစ်မနေလိုက်နာရန်) -\n"
            f"၁။ ⚠️ အရေးကြီးဆုံးအချက် - ပေးထားသော အပိုင်း (Episode) သို့မဟုတ် ဇာတ်လမ်းတွဲ၏ ဇာတ်ကွက် အစမှ အဆုံးထိ 'ဇာတ်သိမ်းပိုင်း (Ending)' ကို မဖြစ်မနေ ထည့်သွင်းရမည်။ လမ်းတစ်ဝက်တွင် စာသားဖြတ်တောက်ပြီး ပရိသတ်ကို မျှော်ခိုင်းထားခြင်းမျိုး လုံးဝ (လုံးဝ) မလုပ်ရပါ။ တစ်ပုဒ်လုံး အပြီးသတ်ပေးရမည်။\n"
            f"၂။ စကားပြောဟန်က ပရိသတ်ကို ဆွဲဆောင်မှုရှိပြီး ဇာတ်ရှိန်တက်အောင် စိတ်လှုပ်ရှားစရာ အပြည့်ဖြစ်ရမယ်။ စာအုပ်ဖတ်ပြသလိုမျိုး လုံးဝ မလုပ်ပါနဲ့။\n"
            f"၃။ ဒါက {length_desc} ဖြစ်လို့ မြန်မာစာသားကို {word_count} အပြည့်အစုံ ချရေးပေးပါ။ စာလုံးရေ ကန့်သတ်ချက်အတွင်းမှာပဲ ဇာတ်လမ်းတစ်ခုလုံး ပြီးဆုံးသွားအောင် အချိန်အဆ တတ်နိုင်သမျှ မျှပြီး ရေးပေးပါ။\n"
            f"၄။ Creator Tips တွေ၊ ဇာတ်ကွက်ဖော်ပြချက်တွေ (ဥပမာ- Visual: ...) လုံးဝ ထည့်မပေးပါနဲ့။ နောက်ခံစကားပြော (Voiceover) အတွက် မြန်မာလို စကားပြောစာသား သီးသန့်ကိုပဲ ချရေးပေးရပါမယ်।"
        )
        
        response = client.models.generate_content(model='gemini-2.5-flash', contents=script_prompt)
        burmese_script = response.text
        
        # 💾 အောင်မြင်ပါက Usage Count မှတ်သားမည်
        if user_info["role"] != "admin":
            user_info["last_used_date"] = today_str
            user_info["usage_count"] = 1
            db[logged_in_user] = user_info
            save_db(db)
            
        return burmese_script
        
    except Exception as e:
        return f"❌ Error တက်သွားပါတယ်- {str(e)}"

# 👑 [ADMIN FEATURE]: Member သစ်ထည့်ခြင်း
def admin_add_member(new_username, new_password):
    new_username = new_username.strip()
    new_password = new_password.strip()
    
    if not new_username or not new_password:
        return "❌ Username နှင့် Password အားလုံး ရိုက်ထည့်ပေးပါ။", get_members_table()
        
    db = load_db()
    if new_username in db:
        return f"❌ အသုံးပြုသူနာမည် '{new_username}' သည် ရှိနှင့်ပြီးသား ဖြစ်နေသည်။", get_members_table()
        
    expiry_date = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")
    db[new_username] = {
        "password": new_password,
        "role": "member",
        "expiry_date": expiry_date,
        "last_used_date": "",
        "usage_count": 0
    }
    save_db(db)
    return f"✅ Paid Member '{new_username}' အား (၁) လ သက်တမ်းဖြင့် အောင်မြင်စွာ တည်ဆောက်ပြီးပါပြီ။", get_members_table()

# 👑 [ADMIN FEATURE]: Member အား ပြန်ဖျက်ခြင်း ခလုတ်
def admin_delete_member(username_to_delete):
    username_to_delete = username_to_delete.strip()
    if not username_to_delete:
        return "❌ ကျေးဇူးပြု၍ ဖျက်လိုသော Username ကို ရိုက်ထည့်ပါ။", get_members_table()
        
    db = load_db()
    if username_to_delete in db:
        if db[username_to_delete]["role"] == "member":
            del db[username_to_delete]
            save_db(db)
            return f"🗑️ Paid Member '{username_to_delete}' အား စနစ်ထဲမှ အပြီးဖျက်လိုက်ပါပြီ။", get_members_table()
        else:
            return "❌ Admin သို့မဟုတ် Free User အကောင့်ကို ဖျက်၍မရပါ။", get_members_table()
    return f"❌ အသုံးပြုသူ '{username_to_delete}' ကို ရှာမတွေ့ပါ။", get_members_table()

# 👑 [ADMIN FEATURE]: Member ဇယားထုတ်ပေးခြင်း
def get_members_table():
    db = load_db()
    table_data = []
    for user, data in db.items():
        if data["role"] == "member":
            table_data.append([user, data["password"], data["expiry_date"], data.get("last_used_date", "မရှိသေး"), "ပြည့်" if data.get("usage_count",0)>=1 else "ကျန်"])
    return table_data

# =====================================================================
# 🎨 GRADIO UI DESIGN WITH SECURITY SYSTEM
# =====================================================================
with gr.Blocks(title="Smart Movie Auto Recap Pro") as demo:
    current_logged_user = gr.State(value="")
    
    gr.Markdown("# ✨ Smart Movie Auto Recap Pro (v 2.0) ✨")
    gr.Markdown("🛡️ Secure Account Control & Professional Script Generator")
    
    status_output = gr.Textbox(label="ℹ️ Login Status", value="🔒 ကျေးဇူးပြု၍ စနစ်အတွင်းသို့ အရင်ဝင်ရောက်ပေးပါ။", interactive=False)
    
    # 1. 🔐 LOGIN BOX
    with gr.Group() as login_box:
        gr.Markdown("### 🔐 အကောင့်ဝင်ရန်")
        username_input = gr.Textbox(label="Username", placeholder="👤 Username ရိုက်ထည့်ပါ")
        password_input = gr.Textbox(label="Password", placeholder="🔑 Password ရိုက်ထည့်ပါ", type="password")
        login_btn = gr.Button("Login ဝင်မည်", variant="primary")
        
    # 2. 👑 ADMIN CONTROL PANEL
    with gr.Group(visible=False) as admin_panel:
        gr.Markdown("## 👑 Admin Control Panel (Member Management)")
        with gr.Row():
            with gr.Column():
                gr.Markdown("### ➕ Member အသစ် ထည့်ရန်")
                new_user_in = gr.Textbox(label="Member သစ်၏ Username", placeholder="ဥပမာ - member_mgmg")
                new_pass_in = gr.Textbox(label="Member သစ်၏ Password", placeholder="ဥပမာ - mgmg123")
                add_member_btn = gr.Button("➕ Paid Member အသစ် ဆောက်မည် (၁ လ သက်တမ်း)", variant="secondary")
                
                gr.Markdown("---")
                gr.Markdown("### 🗑️ Member အား ပြန်ဖျက်ရန်")
                delete_user_in = gr.Textbox(label="ဖျက်လိုသော Username ကို ရိုက်ထည့်ပါ", placeholder="ဥပမာ - member_mgmg")
                delete_member_btn = gr.Button("🗑️ Member အား စနစ်ထဲမှ ဖျက်မည်", variant="stop")
                
                admin_action_status = gr.Textbox(label="📊 လုပ်ဆောင်မှု အခြေအနေပြချက်", interactive=False)
            with gr.Column():
                gr.Markdown("### 👥 လက်ရှိ Paid Members များစာရင်း")
                members_table = gr.Dataframe(
                    headers=["Username", "Password", "Expiry Date", "Last Used Date", "Today Limit"],
                    datatype=["str", "str", "str", "str", "str"],
                    value=get_members_table()
                )

    # 3. 🎬 MAIN RECAP STUDIO BOX
    with gr.Group(visible=False) as main_studio_box:
        with gr.Row():
            with gr.Column():
                gr.Markdown("### ⚙️ Recap Configurations")
                api_key_input = gr.Textbox(label="🔑 သင်၏ Gemini API Key", placeholder="AI Studio Key ထည့်ရန်", type="password")
                movie_name_input = gr.Textbox(label="🍿 ရုပ်ရှင် သို့မဟုတ် စီးရီးနာမည်", placeholder="ဥပမာ- True Education (Korean Series)")
                episode_input = gr.Textbox(label="🎬 အပိုင်း (Episode / Part / Season) (Optional)", placeholder="ဥပမာ- Episode 1")
                
                movie_context_input = gr.Textbox(
                    label="📝 ဇာတ်လမ်းအကျဉ်း သို့မဟုတ် အချက်အလက် (Optional)", 
                    placeholder="ပိုမိုတိကျစေရန် ဇာတ်လမ်းအကျဉ်းကို ထည့်ပေးနိုင်ပါသည်။",
                    lines=4
                )
                
                duration_dropdown = gr.Dropdown(
                    choices=["Short (TikTok/Reels - 1 Min)", "Medium (YouTube - 3 to 5 Mins)", "Long (YouTube - 10 to 15 Mins)"],
                    value="Medium (YouTube - 3 to 5 Mins)",
                    label="⏱️ ဗီဒီယို အချိန်အရှည်"
                )
                submit_btn = gr.Button("🚀 Auto Process စတင်မည်", variant="primary")
                
            with gr.Column():
                gr.Markdown("### 📝 ထွက်ပေါ်လာသော ရလဒ်")
                output_script = gr.Textbox(label="📝 ထွက်လာသည့် မြန်မာလို Script", interactive=False, lines=18)
                
    # 🔗 Login လုပ်ဆောင်ချက် ချိတ်ဆက်ခြင်း
    def login_pipeline(u, p):
        box_vis, studio_vis, admin_vis, msg = check_login(u, p)
        logged_user = u.strip() if "❌" not in msg and "🚫" not in msg else ""
        return box_vis, studio_vis, admin_vis, msg, logged_user

    login_btn.click(
        fn=login_pipeline,
        inputs=[username_input, password_input],
        outputs=[login_box, main_studio_box, admin_panel, status_output, current_logged_user]
    )

    # 🔗 Script ထုတ်လုပ်ခြင်း ခလုတ်ချိတ်ဆက်ခြင်း
    submit_btn.click(
        fn=process_movie_recap,
        inputs=[current_logged_user, movie_name_input, episode_input, movie_context_input, api_key_input, duration_dropdown],
        outputs=[output_script]
    )
    
    # 🔗 Admin Add Member 
    add_member_btn.click(
        fn=admin_add_member,
        inputs=[new_user_in, new_pass_in],
        outputs=[admin_action_status, members_table]
    )
    
    # 🔗 Admin Delete Member
    delete_member_btn.click(
        fn=admin_delete_member,
        inputs=[delete_user_in],
        outputs=[admin_action_status, members_table]
    )

if __name__ == "__main__":
    demo.launch()