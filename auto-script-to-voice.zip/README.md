---
title: Auto Script To Voice
emoji: 📉
colorFrom: green
colorTo: pink
sdk: gradio
sdk_version: 6.19.0
python_version: '3.13'
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
